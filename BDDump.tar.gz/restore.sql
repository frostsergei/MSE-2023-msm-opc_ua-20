--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE logika;
--
-- Name: logika; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE logika WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE logika OWNER TO postgres;

\connect logika

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archive_types; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.archive_types (
    type text,
    description text,
    comment text,
    id integer NOT NULL
);


ALTER TABLE public.archive_types OWNER TO skygrel19;

--
-- Name: archive_types_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.archive_types ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.archive_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buses; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.buses (
    id integer NOT NULL,
    key text,
    description text
);


ALTER TABLE public.buses OWNER TO skygrel19;

--
-- Name: buses_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.buses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.buses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: channels; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.channels (
    id integer NOT NULL,
    device text,
    key text,
    description text,
    start boolean,
    count integer
);


ALTER TABLE public.channels OWNER TO skygrel19;

--
-- Name: channels_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.channels ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: data_types; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.data_types (
    id integer NOT NULL,
    name text,
    description text
);


ALTER TABLE public.data_types OWNER TO skygrel19;

--
-- Name: data_types_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.data_types ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.data_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    key text,
    bus text,
    m4 boolean,
    description text,
    media text,
    pipes integer,
    consumers integer,
    aux_no integer
);


ALTER TABLE public.devices OWNER TO skygrel19;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.devices ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: l4_archive_fields; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.l4_archive_fields (
    id integer NOT NULL,
    device text,
    archive_type text,
    field_offset integer,
    name text,
    internal_type text,
    data_type text,
    description text,
    var_t text,
    units text,
    db_type text
);


ALTER TABLE public.l4_archive_fields OWNER TO skygrel19;

--
-- Name: l4_archive_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.l4_archive_fields ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.l4_archive_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: l4_tags; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.l4_tags (
    id integer NOT NULL,
    device text,
    channel text,
    ordinal integer,
    kind text,
    basic integer,
    data_type text,
    db_type text,
    update_rate integer,
    name text,
    display_format text,
    description text,
    var_t text,
    units text,
    internal_type text,
    in_ram boolean,
    address integer,
    channel_offset integer,
    addon integer,
    addon_offset integer,
    description_ex text,
    range text
);


ALTER TABLE public.l4_tags OWNER TO skygrel19;

--
-- Name: l4_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.l4_tags ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.l4_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: l4_types; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.l4_types (
    id integer NOT NULL,
    type text,
    description text,
    comment text
);


ALTER TABLE public.l4_types OWNER TO skygrel19;

--
-- Name: l4_types_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.l4_types ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.l4_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m4_archive_fields; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.m4_archive_fields (
    id integer NOT NULL,
    device text,
    archive_type text,
    index integer,
    name text,
    datatype text,
    description text,
    var_t text,
    units text,
    db_type text,
    display_format text
);


ALTER TABLE public.m4_archive_fields OWNER TO skygrel19;

--
-- Name: m4_archive_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.m4_archive_fields ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m4_archive_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m4_archives; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.m4_archives (
    id integer NOT NULL,
    device text,
    archive_type text,
    channel text,
    record_type text,
    name text,
    description text,
    capacity integer
);


ALTER TABLE public.m4_archives OWNER TO skygrel19;

--
-- Name: m4_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.m4_archives ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m4_archives_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: m4_tags; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.m4_tags (
    id integer NOT NULL,
    device text,
    channel text,
    ordinal integer,
    kind text,
    basic integer,
    datatype text,
    db_type text,
    update_rate integer,
    name text,
    display_format text,
    description text,
    var_t text,
    units text,
    description_ex text,
    range text
);


ALTER TABLE public.m4_tags OWNER TO skygrel19;

--
-- Name: m4_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.m4_tags ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.m4_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tag_kinds; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.tag_kinds (
    id integer NOT NULL,
    kind text,
    description text
);


ALTER TABLE public.tag_kinds OWNER TO skygrel19;

--
-- Name: tag_kinds_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.tag_kinds ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tag_kinds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vars; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.vars (
    id integer NOT NULL,
    var_t text,
    description text
);


ALTER TABLE public.vars OWNER TO skygrel19;

--
-- Name: vars_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.vars ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.vars_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: x6_archive_fields; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.x6_archive_fields (
    id integer NOT NULL,
    device text,
    archive_type text,
    channel text,
    ordinal integer,
    data_type text,
    db_type text,
    name text,
    description text,
    var_t text,
    start_index integer,
    count integer,
    depth integer,
    comment text
);


ALTER TABLE public.x6_archive_fields OWNER TO skygrel19;

--
-- Name: x6_archive_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.x6_archive_fields ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.x6_archive_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: x6_archives; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.x6_archives (
    id integer NOT NULL,
    device text,
    archive_type text,
    ordinal text,
    record_type text,
    name text,
    description text,
    capacity integer
);


ALTER TABLE public.x6_archives OWNER TO skygrel19;

--
-- Name: x6_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.x6_archives ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.x6_archives_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: x6_tag_type; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.x6_tag_type (
    id integer NOT NULL,
    type text
);


ALTER TABLE public.x6_tag_type OWNER TO skygrel19;

--
-- Name: x6_tag_type_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.x6_tag_type ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.x6_tag_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: x6_tags; Type: TABLE; Schema: public; Owner: skygrel19
--

CREATE TABLE public.x6_tags (
    id integer NOT NULL,
    device text,
    channel text,
    ordinal integer,
    index integer,
    type text,
    kind text,
    basic boolean,
    data_type text,
    update_rate integer,
    name text,
    description text,
    var_t text,
    count integer,
    description_ex text,
    range text
);


ALTER TABLE public.x6_tags OWNER TO skygrel19;

--
-- Name: x6_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: skygrel19
--

ALTER TABLE public.x6_tags ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.x6_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: archive_types; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.archive_types (type, description, comment, id) FROM stdin;
\.
COPY public.archive_types (type, description, comment, id) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: buses; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.buses (id, key, description) FROM stdin;
\.
COPY public.buses (id, key, description) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.channels (id, device, key, description, start, count) FROM stdin;
\.
COPY public.channels (id, device, key, description, start, count) FROM '$$PATH$$/3466.dat';

--
-- Data for Name: data_types; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.data_types (id, name, description) FROM stdin;
\.
COPY public.data_types (id, name, description) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.devices (id, key, bus, m4, description, media, pipes, consumers, aux_no) FROM stdin;
\.
COPY public.devices (id, key, bus, m4, description, media, pipes, consumers, aux_no) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: l4_archive_fields; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.l4_archive_fields (id, device, archive_type, field_offset, name, internal_type, data_type, description, var_t, units, db_type) FROM stdin;
\.
COPY public.l4_archive_fields (id, device, archive_type, field_offset, name, internal_type, data_type, description, var_t, units, db_type) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: l4_tags; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.l4_tags (id, device, channel, ordinal, kind, basic, data_type, db_type, update_rate, name, display_format, description, var_t, units, internal_type, in_ram, address, channel_offset, addon, addon_offset, description_ex, range) FROM stdin;
\.
COPY public.l4_tags (id, device, channel, ordinal, kind, basic, data_type, db_type, update_rate, name, display_format, description, var_t, units, internal_type, in_ram, address, channel_offset, addon, addon_offset, description_ex, range) FROM '$$PATH$$/3474.dat';

--
-- Data for Name: l4_types; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.l4_types (id, type, description, comment) FROM stdin;
\.
COPY public.l4_types (id, type, description, comment) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: m4_archive_fields; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.m4_archive_fields (id, device, archive_type, index, name, datatype, description, var_t, units, db_type, display_format) FROM stdin;
\.
COPY public.m4_archive_fields (id, device, archive_type, index, name, datatype, description, var_t, units, db_type, display_format) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: m4_archives; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.m4_archives (id, device, archive_type, channel, record_type, name, description, capacity) FROM stdin;
\.
COPY public.m4_archives (id, device, archive_type, channel, record_type, name, description, capacity) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: m4_tags; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.m4_tags (id, device, channel, ordinal, kind, basic, datatype, db_type, update_rate, name, display_format, description, var_t, units, description_ex, range) FROM stdin;
\.
COPY public.m4_tags (id, device, channel, ordinal, kind, basic, datatype, db_type, update_rate, name, display_format, description, var_t, units, description_ex, range) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: tag_kinds; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.tag_kinds (id, kind, description) FROM stdin;
\.
COPY public.tag_kinds (id, kind, description) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: vars; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.vars (id, var_t, description) FROM stdin;
\.
COPY public.vars (id, var_t, description) FROM '$$PATH$$/3486.dat';

--
-- Data for Name: x6_archive_fields; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.x6_archive_fields (id, device, archive_type, channel, ordinal, data_type, db_type, name, description, var_t, start_index, count, depth, comment) FROM stdin;
\.
COPY public.x6_archive_fields (id, device, archive_type, channel, ordinal, data_type, db_type, name, description, var_t, start_index, count, depth, comment) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: x6_archives; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.x6_archives (id, device, archive_type, ordinal, record_type, name, description, capacity) FROM stdin;
\.
COPY public.x6_archives (id, device, archive_type, ordinal, record_type, name, description, capacity) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: x6_tag_type; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.x6_tag_type (id, type) FROM stdin;
\.
COPY public.x6_tag_type (id, type) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: x6_tags; Type: TABLE DATA; Schema: public; Owner: skygrel19
--

COPY public.x6_tags (id, device, channel, ordinal, index, type, kind, basic, data_type, update_rate, name, description, var_t, count, description_ex, range) FROM stdin;
\.
COPY public.x6_tags (id, device, channel, ordinal, index, type, kind, basic, data_type, update_rate, name, description, var_t, count, description_ex, range) FROM '$$PATH$$/3494.dat';

--
-- Name: archive_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.archive_types_id_seq', 12, true);


--
-- Name: buses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.buses_id_seq', 2, true);


--
-- Name: channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.channels_id_seq', 68, true);


--
-- Name: data_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.data_types_id_seq', 8, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.devices_id_seq', 26, true);


--
-- Name: l4_archive_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.l4_archive_fields_id_seq', 213, true);


--
-- Name: l4_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.l4_tags_id_seq', 385, true);


--
-- Name: l4_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.l4_types_id_seq', 18, true);


--
-- Name: m4_archive_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.m4_archive_fields_id_seq', 864, true);


--
-- Name: m4_archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.m4_archives_id_seq', 35, true);


--
-- Name: m4_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.m4_tags_id_seq', 967, true);


--
-- Name: tag_kinds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.tag_kinds_id_seq', 4, true);


--
-- Name: vars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.vars_id_seq', 12, true);


--
-- Name: x6_archive_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.x6_archive_fields_id_seq', 703, true);


--
-- Name: x6_archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.x6_archives_id_seq', 93, true);


--
-- Name: x6_tag_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.x6_tag_type_id_seq', 3, true);


--
-- Name: x6_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: skygrel19
--

SELECT pg_catalog.setval('public.x6_tags_id_seq', 13368, true);


--
-- Name: archive_types archive_types_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.archive_types
    ADD CONSTRAINT archive_types_pkey PRIMARY KEY (id);


--
-- Name: buses buses_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.buses
    ADD CONSTRAINT buses_pkey PRIMARY KEY (id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: data_types data_types_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.data_types
    ADD CONSTRAINT data_types_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: l4_archive_fields l4_archive_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.l4_archive_fields
    ADD CONSTRAINT l4_archive_fields_pkey PRIMARY KEY (id);


--
-- Name: l4_tags l4_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.l4_tags
    ADD CONSTRAINT l4_tags_pkey PRIMARY KEY (id);


--
-- Name: l4_types l4_types_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.l4_types
    ADD CONSTRAINT l4_types_pkey PRIMARY KEY (id);


--
-- Name: m4_archive_fields m4_archive_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.m4_archive_fields
    ADD CONSTRAINT m4_archive_fields_pkey PRIMARY KEY (id);


--
-- Name: m4_archives m4_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.m4_archives
    ADD CONSTRAINT m4_archives_pkey PRIMARY KEY (id);


--
-- Name: m4_tags m4_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.m4_tags
    ADD CONSTRAINT m4_tags_pkey PRIMARY KEY (id);


--
-- Name: tag_kinds tag_kinds_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.tag_kinds
    ADD CONSTRAINT tag_kinds_pkey PRIMARY KEY (id);


--
-- Name: vars vars_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.vars
    ADD CONSTRAINT vars_pkey PRIMARY KEY (id);


--
-- Name: x6_archive_fields x6_archive_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.x6_archive_fields
    ADD CONSTRAINT x6_archive_fields_pkey PRIMARY KEY (id);


--
-- Name: x6_archives x6_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.x6_archives
    ADD CONSTRAINT x6_archives_pkey PRIMARY KEY (id);


--
-- Name: x6_tag_type x6_tag_type_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.x6_tag_type
    ADD CONSTRAINT x6_tag_type_pkey PRIMARY KEY (id);


--
-- Name: x6_tags x6_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: skygrel19
--

ALTER TABLE ONLY public.x6_tags
    ADD CONSTRAINT x6_tags_pkey PRIMARY KEY (id);


--
-- Name: DATABASE logika; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE logika TO skygrel19;


--
-- PostgreSQL database dump complete
--

